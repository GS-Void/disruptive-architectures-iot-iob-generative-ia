#include <WiFi.h>
#include <PubSubClient.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

// Wi-Fi
const char* ssid = "Wokwi-GUEST";
const char* password = "";

// Configurações API Java
const char* api_url = "https://java-advanced-5ce0.onrender.com/api/sessoes";

// Configurações MQTT
const char* mqtt_server = "broker.hivemq.com";
WiFiClient espClient;
PubSubClient client(espClient);

// Configuração do OLED 
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

// Pinos
const int pinoBPM = 34;    // Entrada 1
const int pinoFadiga = 35; // Entrada 2
const int ledNormal = 4;   // Saída 1 
const int ledAlerta = 2;   // Saída 2

unsigned long ultimaMensagem = 0;

void setup() {
  Serial.begin(115200);
  pinMode(pinoBPM, INPUT);
  pinMode(pinoFadiga, INPUT);
  pinMode(ledNormal, OUTPUT);
  pinMode(ledAlerta, OUTPUT);

  if(!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    for(;;);
  }

  display.clearDisplay();
  display.setTextColor(WHITE);
  display.setCursor(0, 10);
  display.println("Conectando Wi-Fi...");
  display.display();

  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) delay(500);
  
  client.setServer(mqtt_server, 1883);
}

void loop() {
  if (!client.connected()) {
    while (!client.connected()) client.connect("VOID_ESP32_Team");
  }
  client.loop();

  long agora = millis();
  if (agora - ultimaMensagem > 10000) { // Envia a cada 10 segundos
    ultimaMensagem = agora;

    // Leitura das Entradas
    int bpm = map(analogRead(pinoBPM), 0, 4095, 60, 180);
    float fadiga = (analogRead(pinoFadiga) / 4095.0) * 100.0;

    // Lógica das Saídas 
    if (fadiga > 80.0 || bpm > 150) {
      digitalWrite(ledNormal, LOW);
      digitalWrite(ledAlerta, HIGH); 
    } else {
      digitalWrite(ledNormal, HIGH);
      digitalWrite(ledAlerta, LOW);
    }

    // Interface Local OLED 
    display.clearDisplay();
    display.setCursor(0, 0);
    display.setTextSize(1);
    display.println("VOID - Space Health");
    display.print("BPM: "); display.println(bpm);
    display.print("Fadiga: "); display.print(fadiga, 1); display.println("%");
    display.display();

    // 1. Enviar para o Node-RED 
    client.publish("fiap/void/bpm", String(bpm).c_str());
    client.publish("fiap/void/fadiga", String(fadiga).c_str());

    // Enviar para a sua API Java no Render
    if (WiFi.status() == WL_CONNECTED) {
      HTTPClient http;
      http.begin(api_url);
      http.addHeader("Content-Type", "application/json");

      http.addHeader("Authorization", "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJBUEkgVk9JRCIsInN1YiI6ImEiLCJleHAiOjE3ODA4NzkwNTh9.3d1NFqrf52i-5dKu9NBJXxNnt8QKvUNYhVmKgB5dMMc");

      StaticJsonDocument<200> doc;
      doc["pacienteId"] = 1; 
      doc["dataSessao"] = "2026-06-07"; 
      doc["desgasteAcumulado"] = fadiga;

      String json;
      serializeJson(doc, json);
      
      int httpCode = http.POST(json);
      Serial.println("Payload Enviado: " + json);
      Serial.println("Status API Java: " + String(httpCode));
      http.end();
    }
  }
}